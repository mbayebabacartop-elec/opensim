﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$qtBin = 'C:\Qt\6.10.3\msvc2022_64\bin'
$exe = Join-Path $root 'build\windows-msvc-release\Release\openlab_app.exe'
if (-not (Test-Path -LiteralPath $exe)) {
    throw 'Build Release introuvable. Lancez d’abord cmake --build --preset windows-msvc-release.'
}
if (-not (Test-Path -LiteralPath (Join-Path $qtBin 'Qt6Widgets.dll'))) {
    throw "Qt Widgets 6.10.3 est introuvable dans $qtBin."
}
$env:PATH = "$qtBin;$env:PATH"
Start-Process -FilePath $exe -WorkingDirectory $root
